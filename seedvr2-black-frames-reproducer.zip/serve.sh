#!/usr/bin/env bash
set -euo pipefail

: "${MODEL_DIR:?Set MODEL_DIR to the absolute path of the converted SeedVR2 model directory}"
case "${1:-}" in
    fp16) precision_args=() ;;
    bf16) precision_args=(--additional-config '{"seedvr2_dit_compute_dtype":"bfloat16"}') ;;
    *) echo 'Usage: bash serve.sh fp16|bf16' >&2; exit 2 ;;
esac

export CUDA_VISIBLE_DEVICES="${CUDA_VISIBLE_DEVICES:-0,1,2,3}"
export VLLM_OMNI_SEEDVR2_SHARDED_FRAME_PIXELS=3791872
export VLLM_OMNI_SEEDVR2_SHARDED_CLIP_PIXELS=246471680
export VLLM_OMNI_SEEDVR2_MAX_FRAMES=65
export VLLM_OMNI_SEEDVR2_LONG_MAX_WINDOW=33

exec vllm serve "$MODEL_DIR" --omni --model-class-name SeedVR2Pipeline \
    --dtype float16 --enforce-eager --cache-backend none \
    --num-gpus 4 --distributed-executor-backend mp --vae-use-tiling \
    --stage-overrides '{"0":{"ulysses_degree":4,"vae_patch_parallel_size":4,"vae_parallel_mode":"spatial_shard_height"}}' \
    --api-server-count 1 --tensor-parallel-size 1 --ring-degree 1 \
    --cfg-parallel-size 1 --allgather-degree 1 --text-encoder-tp-size 1 \
    --ulysses-mode strict --no-ulysses-a2a-permute --max-num-seqs 1 \
    --request-batch-max-wait-ms 0 "${precision_args[@]}" --host 127.0.0.1 --port 8098
