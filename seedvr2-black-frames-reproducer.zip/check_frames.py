"""Count black frames in the delivered 33-frame, 2016x1152 SeedVR2 MP4."""

import argparse
import json
import subprocess
from fractions import Fraction
from pathlib import Path


def inspect(path, ffprobe, ffmpeg):
    metadata = subprocess.check_output([
        ffprobe, "-v", "error", "-select_streams", "v:0", "-show_entries",
        "stream=width,height,avg_frame_rate", "-of", "json", str(path),
    ])
    stream, = json.loads(metadata)["streams"]
    width, height = stream["width"], stream["height"]
    if (width, height) != (2016, 1152) or Fraction(stream["avg_frame_rate"]) != 24:
        raise ValueError(f"Expected 2016x1152 at 24 fps, got {stream}")
    frame_bytes = width * height * 3
    maxima = []
    with subprocess.Popen([
        ffmpeg, "-nostdin", "-v", "error", "-xerror", "-i", str(path), "-map", "0:v:0",
        "-an", "-fps_mode", "passthrough", "-f", "rawvideo", "-pix_fmt", "rgb24", "pipe:1",
    ], stdout=subprocess.PIPE) as decoder:
        while data := decoder.stdout.read(frame_bytes):
            if len(data) != frame_bytes:
                raise ValueError("Partial RGB frame")
            maxima.append(max(data))
        if decoder.wait() != 0:
            raise ValueError("FFmpeg could not decode the complete video")
    if len(maxima) != 33:
        raise ValueError(f"Expected 33 decoded frames, got {len(maxima)}")
    return {"decoded": len(maxima), "width": width, "height": height, "fps": 24,
            "all_black": sum(value == 0 for value in maxima),
            "black_or_near_black": sum(value <= 2 for value in maxima),
            "max_rgb_by_frame": maxima}


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("video", type=Path)
    parser.add_argument("--ffprobe", default="ffprobe")
    parser.add_argument("--ffmpeg", default="ffmpeg")
    args = parser.parse_args()
    print(json.dumps(inspect(args.video, args.ffprobe, args.ffmpeg), indent=2))
