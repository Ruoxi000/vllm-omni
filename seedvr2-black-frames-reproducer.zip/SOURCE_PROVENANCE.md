# Source, checkpoint and media provenance

## Supplied media

All original media files were copied byte-for-byte. Display derivatives are named separately; no weights or complete private logs are included.

| File | SHA256 |
|---|---|
| `media/failure-input-33f.nut` | `e9c762da293794322afb46a22fbb45fbc1c0e0fd4c983a616f9b3bf3bee379bc` |
| `media/fp16-failure-33f-raw.mp4` | `40d4ab344baf4bf0c1397281ba011d49d0542fd5292b33dd4b703b5f447c8f72` |
| `media/bf16-fixed-33f-raw.mp4` | `1913e91462f0ac3a8c9f13c2c551927e1409db9ccfb6a8e830f4af39b4dc0132` |

The contact sheet contains actual decoded frames 0/16/32, proportionally resized and labelled. The input MP4 is a new browser-viewing derivative, not the lossless reproduction source. See [media/README.md](media/README.md).

## Official FP32 source used for the matched comparison

Repository: [ByteDance-Seed/SeedVR2-3B](https://huggingface.co/ByteDance-Seed/SeedVR2-3B/tree/37255ff8cccfb01071b87f635a5948ca8d53117c).

Revision: `37255ff8cccfb01071b87f635a5948ca8d53117c`.

| Source file | SHA256 |
|---|---|
| `seedvr2_ema_3b.pth` | `6bcc5ac59447e97b100477480aebb01be2ec724c8340bb83faae21f64848604b` |
| `ema_vae.pth` | `c7df8a67e68b7f9aca3d5d2153d2ce8ab4373687741a0f9ce87cb356ace51cac` |
| `pos_emb.pt` | `fa07a14844314772266b66c3b95deb0027696d8fe7065721263db5176f45d799` |

The existing [conversion script](https://github.com/githubgxll/dynamo/blob/f35ce0ee8db32c275a2c343e243ccafe6734a337/delivery/h3-sr-production/convert_seedvr2.py) is included unchanged as `tools/convert_seedvr2.py`; SHA256 `cab495159e2739c53a1578f4195fc5f4cc17df7380db08ee308b5cf1179fb6fd`. It preserves keys and integer buffers, casts floating tensors to FP16 on CPU, checks finite values, and reopens the result to verify exact cast tensors. This was not retraining.

Archived conversion: Torch2.13.0+cu130 and safetensors0.8.0; 635 DiT tensors including buffers and 250 VAE tensors. The fixed condition file was copied unchanged.

| Tested derived file | SHA256 |
|---|---|
| `seedvr2_ema_3b_fp16.safetensors` | `fc7aabe77db395e57b2b55339ed3c51708456220c01fa84f1ceb89e3548d7684` |
| `ema_vae_fp16.safetensors` | `c2336fed321c40973a7d0ae2a40557374162bb3784592cce8e276e5469c65fad` |
| `pos_emb.pt` | `fa07a14844314772266b66c3b95deb0027696d8fe7065721263db5176f45d799` |

## Upstream-documented FP16 alternative

The pinned upstream [SeedVR2 guide](https://github.com/vllm-project/vllm-omni/blob/3ffe6e2e3cb9637bdbdd0ac1b69cbbc0e6a04b45/docs/models/seedvr2.md) references FP16 files available from [numz/SeedVR2_comfyUI](https://huggingface.co/numz/SeedVR2_comfyUI/tree/09ced71023636e9bc8cdf9cdecfb2625d1e691e8), revision `09ced71023636e9bc8cdf9cdecfb2625d1e691e8`:

| File | SHA256 |
|---|---|
| `seedvr2_ema_3b_fp16.safetensors` | `2fd0e03a3dad24e07086750360727ca437de4ecd456f769856e960ae93e2b304` |
| `ema_vae_fp16.safetensors` | `20678548f420d98d26f11442d3528f8b8c94e57ee046ef93dbb7633da8612ca1` |

These whole-file hashes differ from the locally converted files. Serialization metadata/order can change the file hash, so this does not establish different tensor values. No tensor-equivalence comparison or failing-input replay using this alternative pair has been completed. Keep its results separate if used for a native replay.

## Code snapshots

| Code | Reference |
|---|---|
| Archived numerical adapter | Local implementation commit `b8255f7cfd9c46062d7b9c1842c05caa5fc224ad`; result boundary is the matched integrated0.32 run, not a native upstream patch |
| Published production extraction | [`githubgxll/dynamo@f35ce0ee8db32c275a2c343e243ccafe6734a337`](https://github.com/githubgxll/dynamo/commit/f35ce0ee8db32c275a2c343e243ccafe6734a337) |
| Native PR base | [`vllm-project/vllm-omni@9b753874d73fb40204418a457d22d802b731d19f`](https://github.com/vllm-project/vllm-omni/commit/9b753874d73fb40204418a457d22d802b731d19f) |
| Upstream NaDiT Git blob | `417dc4397a86a7253500ac4089119afd9543f563` |
| Upstream pipeline Git blob | `8862a4431196c22d23f55aeb91edf0c73e6370e1` |

These are different identities: a production deployment patch and its build validation do not constitute a clean-upstream GPU test.
