# Reproducing intermittent black frames in SeedVR2-3B restoration

An affected job can complete successfully and return a playable MP4 containing a run of black frames. This archive includes the exact input from one such window and the two original outputs from a matched GPU comparison. Open [the synchronized viewer](media/index.html) or inspect the [frame comparison](media/frame-comparison.png).

## Recorded GPU comparison

In our video API, MiniMax-H3 generated an eight-second 1344×768 clip and SeedVR2-3B upscaled it for 1080p delivery. The delivered FP16 video cut to black for 25/192 frames, from 6.2083 s until 7.2500 s. The companion attachment `seedvr2-full-video-comparison.zip` includes the original H3 clip and the full FP16 and BF16 1080p videos with audio.

This archive isolates source frames 145–177 inclusive (zero-based), the affected window before overlap blending. Its 33-frame FP16/BF16 outputs use the same input and request and show the effect of changing the DiT precision.

| Setting | Recorded value |
|---|---|
| Runtime | Integrated vLLM / vLLM-Omni 0.32.0, PyTorch 2.13.0+cu130, Diffusers 0.40.0, Transformers 5.16.1 |
| Input | `media/failure-input-33f.nut`, 1344×768, 33 frames, exact 24 fps, no audio |
| Hardware | Four H100 80GB HBM3 used by SR within an eight-GPU worker. H3 was idle during replay |
| Parallelism | Ulysses/SP4, TP1, ring1, VAE height sharding across four GPUs, VAE tiling enabled |
| Sampling | Seed 17, one Euler step, guidance 1, timestep 1000, fixed text embedding |
| Window | W33, one window, effective overlap zero, no looping |
| Output | 2016×1152, 33 frames at 24 fps, no color correction |

| Observation | Original FP16 | DiT-only BF16 |
|---|---:|---:|
| DiT velocity, shape `[326592,16]` | 5,225,472 of 5,225,472 NaN | All finite, max absolute value 9.4375 |
| Decoded all-black frames | 33 / 33 | 0 / 33 |
| Decoded frames with every RGB channel ≤2 | 33 / 33 | 0 / 33 |

Input, VAE posterior, condition and noise were finite at the observed boundaries. NaNs were already present at the FP16 DiT output and pixels were already zero on the GPU before encoding. The first invalid operation *inside* the DiT is unknown. The full-length BF16 run returned 0/192 black frames and a control returned 0/158. The input and output of the 33-frame pair are the attached videos. [Exact historical request](CASE_PARAMETERS.json) · [Numerical evidence](NUMERIC_EVIDENCE.json)

### Check the attachment without a GPU

Use Python 3.10+ and FFmpeg/FFprobe with `-fps_mode` support. From the extracted directory:

```sh
(cd media && sha256sum -c SHA256SUMS.txt)
python check_frames.py media/fp16-failure-33f-raw.mp4
python check_frames.py media/bf16-fixed-33f-raw.mp4
```

`check_frames.py` decodes every RGB24 frame before counting. The exact input SHA256 is `e9c762da293794322afb46a22fbb45fbc1c0e0fd4c983a616f9b3bf3bee379bc`. Use the NUT for replay. The small MP4 input preview is for playback.

## Run the native PR branch on four GPUs

The archived evidence above comes from an integrated 0.32.0 runtime. The native patch is based on [vLLM-Omni 9b75387](https://github.com/vllm-project/vllm-omni/commit/9b753874d73fb40204418a457d22d802b731d19f). Run both modes using the same patched checkout, model files, GPU topology and API request. The native route decodes via PyAV and rebuilds a window before submitting it. Report the result from this environment independently.

**1. Prepare model files.** Install the PR branch in a supported Linux CUDA environment with four available H100s. Install the archived converter's dependencies (PyTorch, safetensors), `hf`, `requests`, PyAV and FFmpeg/FFprobe. Download the pinned official checkpoint and convert it once on CPU. Use an absolute, new output path for the model. The conversion needs about 20 GiB of free space in addition to the source checkpoint. [Checkpoint hashes and alternatives](SOURCE_PROVENANCE.md)

```sh
export SOURCE_FP32_DIR="$PWD/seedvr2-source-fp32"
export MODEL_DIR="$PWD/seedvr2-model-fp16"
hf download ByteDance-Seed/SeedVR2-3B seedvr2_ema_3b.pth ema_vae.pth pos_emb.pt \
    --revision 37255ff8cccfb01071b87f635a5948ca8d53117c --local-dir "$SOURCE_FP32_DIR"
python tools/convert_seedvr2.py --source-dir "$SOURCE_FP32_DIR" --output-dir "$MODEL_DIR"
```

**2. Run the original FP16 computation.** In terminal A, from this extracted directory, start `bash serve.sh fp16` and wait for server readiness on port 8098. In terminal B, use the same directory and run:

```sh
python replay.py --out native-runs/fp16
```

**3. Change only the DiT precision.** Stop your test server in terminal A after the FP16 request finishes. Run `bash serve.sh bf16` in its place, wait for readiness, then run:

```sh
python replay.py --out native-runs/bf16
```

Both commands send one upload to `POST /v1/seedvr2/restore-long`, poll the returned job ID and download its content. They keep the request, server status, output and frame counts. If polling is interrupted after a submission receipt is saved, append `--resume` to the same command while the same server is still running. If the initial POST disconnects before returning an ID, check that server's job state before retrying. The native request selects W33 through its startup budget. The archived service used an additional request field for this setting.

**4. Record the result.** Preserve both `frames.json` files, MP4s, server logs, GPU model, actual attention backend, exact vLLM, vLLM-Omni and PyTorch revisions, and checkpoint hashes. If native FP16 already generates visible frames, report its measured count alongside BF16. A decoded video cannot establish the internal velocity values; the attached tensor summaries are from the instrumented archived runtime.
