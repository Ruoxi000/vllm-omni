"""Submit the frozen input once to a running native SeedVR2 server and save its output."""

import argparse
import hashlib
import json
import time
from pathlib import Path
from uuid import UUID

import requests

from check_frames import inspect

SOURCE = Path(__file__).resolve().parent / "media" / "failure-input-33f.nut"
EXPECTED = "e9c762da293794322afb46a22fbb45fbc1c0e0fd4c983a616f9b3bf3bee379bc"


def write_json(path, value):
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(value, indent=2) + "\n", encoding="utf8")
    temp.replace(path)


def run(args):
    base = args.url.rstrip("/") + "/v1/seedvr2/restore-long"
    folder = args.out
    if hashlib.sha256(SOURCE.read_bytes()).hexdigest() != EXPECTED:
        raise ValueError("Input checksum differs from the archived lossless input")
    fields = {"prompt": " ", "size": "2016x1152", "num_frames": "33", "loop_input": "false",
              "seed": "17", "extra_params": json.dumps({"color_correction_method": "none"})}
    with requests.Session() as client:
        if args.resume:
            submission = json.loads((folder / "submission.json").read_text(encoding="utf8"))
            if submission["endpoint"] != base:
                raise ValueError("Resume against the same server as the original request")
        else:
            folder.mkdir(parents=True, exist_ok=False)
            write_json(folder / "request.json", {"endpoint": base, "input_sha256": EXPECTED, "form": fields})
            with SOURCE.open("rb") as source:
                response = client.post(base, data=fields, files={
                    "input_references": (SOURCE.name, source, "video/x-nut")}, timeout=(10, 180))
            response.raise_for_status()
            submission = {"endpoint": base, "response": response.json()}
            write_json(folder / "submission.json", submission)
        job_id = submission["response"]["id"]
        UUID(job_id)
        job_url = f"{base}/{job_id}"
        deadline = time.monotonic() + args.timeout
        while True:
            response = client.get(job_url, timeout=30)
            response.raise_for_status()
            status = response.json()
            write_json(folder / "status.json", status)
            if status["status"] == "completed":
                break
            if status["status"] not in ("queued", "running"):
                raise RuntimeError(f"Job {job_id} stopped: {status}")
            if time.monotonic() >= deadline:
                raise TimeoutError(f"Job {job_id} is still pending. Resume this directory with --resume.")
            time.sleep(3)
        target = folder / "output.mp4"
        if not target.exists():
            temp = target.with_suffix(".partial")
            with client.get(job_url + "/content", timeout=(10, 120), stream=True) as response:
                response.raise_for_status()
                with temp.open("wb") as dest:
                    for chunk in response.iter_content(1024 * 1024):
                        dest.write(chunk)
            temp.replace(target)
    result = inspect(target, args.ffprobe, args.ffmpeg)
    write_json(folder / "frames.json", result)
    print(f"{target}: {result['all_black']}/{result['decoded']} black frames")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--url", default="http://127.0.0.1:8098")
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--resume", action="store_true")
    parser.add_argument("--timeout", type=int, default=3600)
    parser.add_argument("--ffprobe", default="ffprobe")
    parser.add_argument("--ffmpeg", default="ffmpeg")
    run(parser.parse_args())
