# Matched SeedVR2 FP16 / BF16 media

Open [index.html](index.html) for three-way local playback and a real-frame comparison. All files are local; there are no network requests or third-party scripts.

## Files

| File | Role | Original or derived |
|---|---|---|
| `failure-input-33f.nut` | Exact reproduction input: 33 frames, 1344×768, 24 FPS | Original uploaded bytes, copied unchanged |
| `fp16-failure-33f-raw.mp4` | Failed native output: 33 black frames, 2016×1152, 24 FPS | Original output bytes, copied unchanged |
| `bf16-fixed-33f-raw.mp4` | Matched DiT-only BF16 output: no black frames, 2016×1152, 24 FPS | Original output bytes, copied unchanged |
| `input-preview-33f.mp4` | Browser preview of the input | Derived H264 CRF18 / yuv420p; **not a reproduction input** |
| `frame-comparison.png` | Real decoded frames 0 / 16 / 32, input / failed / fixed rows | Derived display layout, proportional resizing and labels only |
| `index.html`, `player.js` | Local synchronized comparison viewer | Display tool |

The source clip is the zero-based frame interval 145–177 of the complete 192-frame source video. The repro NUT has losslessly normalized timestamps `n/24`; its pixels and frame order match the frozen failing window. It is not a newly generated or re-encoded test scene.

## Matched configuration and observed result

Both raw outputs correspond to the same exact NUT input and seed 17, one Euler step, CFG 1, SP4 with VAE height sharding, W33, legacy output, no color correction, and a 2016×1152 model canvas. These are the historical matched diagnostic runs, not a clean-upstream replay or a claim that every later production configuration has the same GPU acceptance.

- FP16 native velocity `[326592,16]`: all 5,225,472 elements NaN; decoded output 33/33 all-zero frames.
- DiT-only BF16 native velocity: all finite, absmax 9.4375; the explicit FP16 bridge was finite; decoded output 0/33 all-zero or near-black frames.
- “Near black” here means an entire decoded RGB24 frame has maximum channel value ≤2; natural dark content alone is not labelled a model failure.
- No image-quality score or performance speedup is inferred from this comparison.

The original raw clips have identical output geometry and timestamps. The viewer aligns presentation time approximately; browsers do not offer hardware frame lock. No audio tracks are present in these three clips.

See [SHA256SUMS.txt](SHA256SUMS.txt) for exact file identity. Only `failure-input-33f.nut` should be passed to the exact reproducer; the MP4 preview and the PNG are for presentation.
