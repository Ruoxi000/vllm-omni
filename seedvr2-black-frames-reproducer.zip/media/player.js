'use strict';
const videos = ['input', 'failed', 'fixed'].map(id => document.getElementById(id));
const master = videos[0];
const playButton = document.getElementById('play');
const timeline = document.getElementById('timeline');
const clock = document.getElementById('clock');
const status = document.getElementById('status');
const fps = 24, lastFrame = 32, lastTime = lastFrame / fps;
let running = false, frameRequest = null, failed = false;
function showTime(time) {
  const value = Math.max(0, Math.min(lastTime, time));
  timeline.value = value;
  clock.value = `${value.toFixed(3)} s · frame ${Math.min(lastFrame, Math.round(value * fps))} / ${lastFrame}`;
}
function stop() {
  running = false;
  videos.forEach(video => video.pause());
  playButton.textContent = 'Play all';
  if (frameRequest !== null) cancelAnimationFrame(frameRequest);
  frameRequest = null;
}
function seek(time) {
  const value = Math.max(0, Math.min(lastTime, time));
  videos.forEach(video => { video.currentTime = value; });
  showTime(value);
}
function tick() {
  if (!running) return;
  const time = master.currentTime;
  videos.slice(1).forEach(video => {
    if (Math.abs(video.currentTime - time) > 0.06) video.currentTime = Math.min(time, lastTime);
  });
  showTime(time);
  frameRequest = requestAnimationFrame(tick);
}
async function play() {
  if (failed) return;
  if (master.currentTime >= lastTime - 0.001) seek(0);
  try {
    const position = master.currentTime;
    videos.slice(1).forEach(video => { video.currentTime = position; });
    await Promise.all(videos.map(video => video.play()));
    running = true;
    playButton.textContent = 'Pause all';
    frameRequest = requestAnimationFrame(tick);
  } catch (error) {
    stop();
    status.textContent = `Playback blocked: ${error.message}. Open this folder in a current browser and press Play all again.`;
    status.className = 'error';
  }
}
playButton.addEventListener('click', () => running ? stop() : play());
document.getElementById('back').addEventListener('click', () => { stop(); seek(Math.round(master.currentTime * fps) / fps - 1 / fps); });
document.getElementById('next').addEventListener('click', () => { stop(); seek(Math.round(master.currentTime * fps) / fps + 1 / fps); });
document.getElementById('reset').addEventListener('click', () => { stop(); seek(0); });
timeline.addEventListener('input', () => { stop(); seek(Number(timeline.value)); });
document.getElementById('speed').addEventListener('change', event => {
  videos.forEach(video => { video.playbackRate = Number(event.target.value); });
});
master.addEventListener('ended', () => {
  stop();
  if (document.getElementById('loop').checked && !failed) { seek(0); play(); }
  else seek(lastTime);
});
videos.forEach(video => video.addEventListener('error', () => {
  failed = true;
  stop();
  playButton.disabled = true;
  status.className = 'error';
  status.textContent = `Cannot read ${video.getAttribute('src')}. No substitute video has been loaded. Check that all package files are present.`;
}));
Promise.all(videos.map(video => new Promise((resolve, reject) => {
  if (video.readyState >= 1) return resolve();
  video.addEventListener('loadedmetadata', resolve, { once: true });
  video.addEventListener('error', reject, { once: true });
}))).then(() => {
  if (failed) return;
  if (videos.some(video => !Number.isFinite(video.duration) || Math.abs(video.duration - 33 / fps) > 0.05)) {
    throw new Error('A clip duration does not match the frozen 33-frame window.');
  }
  ['play', 'back', 'next', 'reset'].forEach(id => { document.getElementById(id).disabled = false; });
  status.textContent = 'Ready — three matched local clips. The input preview is display-only; reproduce with failure-input-33f.nut.';
  seek(0);
}).catch(error => {
  failed = true;
  status.className = 'error';
  status.textContent = `Media readiness check failed: ${error?.message || 'missing or unreadable local file'}.`;
});
